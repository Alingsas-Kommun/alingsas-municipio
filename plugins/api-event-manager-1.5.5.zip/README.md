
TEMPORARY DOC
apply_filters('event/parser/cbis/import/limit', 2000);
apply_filters('event/parser/common/levenshtein/post_types', array('event', 'location', 'contact'));
