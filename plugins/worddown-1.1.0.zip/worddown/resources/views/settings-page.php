<?php
/**
 * Settings page template
 * 
 * @package Worddown
 */

namespace Worddown;

if (!defined('ABSPATH')) {
    exit;
}

?>

<div class="wrap worddown">
    <div id="worddown-settings-root"></div>
</div> 