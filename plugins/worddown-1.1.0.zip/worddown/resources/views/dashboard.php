<?php
/**
 * Dashboard View
 * 
 * @package Worddown
 */

if (!defined('ABSPATH')) {
    exit;
}

?>

<div class="wrap worddown">
    <div id="worddown-dashboard-root"></div>
</div> 