<?php

return [
    'name' => 'Worddown',
    'version' => function_exists('get_plugin_version') ? get_plugin_version() : '1.0.0',
]; 