<?php

return [
    'plugin_path' => dirname(__DIR__) . '/',
    'plugin_url' => plugin_dir_url(__DIR__),
]; 