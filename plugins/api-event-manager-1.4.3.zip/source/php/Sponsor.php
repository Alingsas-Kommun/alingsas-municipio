<?php

namespace HbgEventImporter;

use \HbgEventImporter\Helper\DataCleaner as DataCleaner;

class Sponsor extends \HbgEventImporter\Entity\PostManager
{
    public $post_type = 'sponsor';
}
